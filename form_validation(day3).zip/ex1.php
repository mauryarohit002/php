<?php
	$x1=100;
	$x2=200;

	echo $x1,$x2;
	// print $x1,$x2;
	print $x1;
	print $x2;
?>