<?php
	// numeric array
	$data = ["PHP","MySQL","Ajax"];
	// echo $data;
	print_r($data);
	echo "<br>";
	echo $data[1];
	print_r($data[1]);
?>