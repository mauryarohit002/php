<?php
	// single line
	# single line
	/* single line */
	for($i=1;$i<=5;$i++)
	{
		echo $i;
		echo "<br>";
	}

	$j=1;
	while($j<=5){
		echo pow($j,2) . "<br>";
		$j++;
	}
?>