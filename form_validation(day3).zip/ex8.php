<?php
	include("hello.php");
	include("hello.php");
	include_once("hello.php");

	// echo 111;
	require("hello.php");
	require("hello.php");
	require_once("hello.php");
	// echo 222;
?>	
