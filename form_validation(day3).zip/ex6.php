<?php
	$data = ["PHP","MySQL","Ajax"];
	print_r($data);

	echo $data[0];
	echo $data[1];
	echo $data[2];

	echo "<hr>";

	for($i=0;$i<count($data);$i++){
		echo $data[$i];
	}

	echo "<hr>";

	$i=0;
	while($i<count($data)){
		echo $data[$i];
		$i++;
	}

	echo "<hr>";

	foreach($data as $ans){
		echo $ans;
	}
?>