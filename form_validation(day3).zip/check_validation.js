check_validation = function(){
	// alert("test");
	// console.log(document);
	// console.log(document.getElementById("uname"));
	txt_name = document.getElementById("uname").value;
	// alert(txt_name);
	ans_name = validate_alpha_space(txt_name);
	if(!ans_name)
	{
		msg = "inavlid Name";
	}
	else{
		txt_mobile = document.getElementById("umobile").value;
		// alert(txt_mobile);
		ans_mob = validate_mobile(txt_mobile);
		// alert(ans_mob);
		if(!ans_mob){
			msg = "Invali Mobile";
		}
		else{
			txt_dob = document.getElementById("udob").value;
			ans_dob = validate_dob(txt_dob);
			if(!ans_dob){
				msg = "inavlid Dob";
			}
			else{
				
				txt_username = document.getElementById("username").value;
				ans_username = validate_username(txt_username);
				if(!ans_username){
					msg = "Invalid Username";
				}
				else{
					txt_email = document.getElementById("uemail").value;
					ans_email = validate_email(txt_email);
					if(!ans_email){
						msg = "Invalid Emailid";
					}
					else{
						txt_pass = document.getElementById("upass").value;
						ans_pass = validate_password(txt_pass);
						if(!ans_pass){
							msg = "Invalid password";
						}
						else{
							txt_cpass = document.getElementById("ucpass").value;
							if(txt_pass!=txt_cpass){
								msg = "Confirm password invalid";
							}
							else{
								msg = "Ok";
							}
						}
					}

				}
			}
		}
	}

	// alert(msg);
	document.getElementById("errmsg").innerHTML=msg;
}