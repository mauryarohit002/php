<?php
	$ans = print_r(100);
	echo $ans;
	var_dump($ans);

	echo "<hr />";

	$ans = print 100;
	echo $ans;
	var_dump($ans);

	echo "<hr />";
	// $ans = echo  100;
?>